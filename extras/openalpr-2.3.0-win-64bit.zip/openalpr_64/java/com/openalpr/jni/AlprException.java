package com.openalpr.jni;


public class AlprException extends Exception {

    public AlprException(String s) {
        super(s);
    }
}
